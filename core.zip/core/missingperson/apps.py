from django.apps import AppConfig


class MissingpersonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'missingperson'


